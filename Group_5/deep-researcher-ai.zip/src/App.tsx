import React, { useState, useEffect, useRef } from 'react';
import { 
  Search, 
  Loader2, 
  CheckCircle2, 
  AlertCircle, 
  FileText, 
  Download, 
  ArrowRight, 
  Sparkles, 
  BrainCircuit, 
  Database, 
  ShieldCheck, 
  Zap,
  Github,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import Markdown from 'react-markdown';
import { cn } from './lib/utils';
import { runResearch, ResearchStep, generateColabCode } from './lib/agents';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';
import { ClipboardCheck, Clipboard } from 'lucide-react';

const SUGGESTED_TOPICS = [
  "The impact of quantum computing on modern cryptography",
  "Future of solid-state batteries in electric vehicles",
  "Ethical implications of AGI in healthcare decision making",
  "Effectiveness of universal basic income in post-industrial economies",
  "The role of mycelium in sustainable architecture"
];

export default function App() {
  const [query, setQuery] = useState('');
  const [isSearching, setIsSearching] = useState(false);
  const [steps, setSteps] = useState<ResearchStep[]>([]);
  const [report, setReport] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isGeneratingPDF, setIsGeneratingPDF] = useState(false);
  const [copied, setCopied] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const reportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [steps]);

  const copyToClipboard = async () => {
    if (!report) return;
    try {
      await navigator.clipboard.writeText(report);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error('Failed to copy:', err);
      setError('Failed to copy to clipboard.');
    }
  };

  const exportToPDF = async () => {
    if (!reportRef.current) return;
    setIsGeneratingPDF(true);
    setError(null);
    
    // Scroll to top of the page to ensure clean capture
    window.scrollTo(0, 0);
    reportRef.current.scrollIntoView({ behavior: 'smooth' });
    
    const element = reportRef.current;
    try {
      // Wait a bit for scroll to finish
      await new Promise(r => setTimeout(r, 500));
      
      const canvas = await html2canvas(element, {
        scale: 1.5,
        useCORS: true,
        backgroundColor: '#0a0a0a',
        logging: true,
        allowTaint: true,
        ignoreElements: (el) => {
          // Ignore elements that might cause issues or are not needed in the report
          return el.classList.contains('no-print') || el.tagName === 'HEADER' || el.tagName === 'FOOTER';
        },
        onclone: (clonedDoc) => {
          const clonedElement = clonedDoc.getElementById('report-container');
          if (clonedElement) {
            clonedElement.style.backdropFilter = 'none';
            clonedElement.style.background = '#0a0a0a';
            clonedElement.style.margin = '0';
            clonedElement.style.borderRadius = '0';
          }
          
          // Inject a style tag to override modern CSS color functions that html2canvas can't parse
          const style = clonedDoc.createElement('style');
          style.innerHTML = `
            #report-container, #report-container * {
              color-scheme: dark !important;
              /* Fallback colors for html2canvas to avoid oklch/oklab parsing errors */
              color: #d1d5db !important; 
              border-color: #374151 !important;
              text-shadow: none !important;
              box-shadow: none !important;
              background-image: none !important;
            }
            #report-container h1, #report-container h2, #report-container h3 {
              color: #3b82f6 !important; /* blue-500 */
            }
            #report-container {
              background-color: #0a0a0a !important;
              padding: 40px !important;
              width: 100% !important;
              max-width: none !important;
            }
            /* Remove any backdrop filters which cause issues */
            * { backdrop-filter: none !important; -webkit-backdrop-filter: none !important; }
          `;
          clonedDoc.head.appendChild(style);
        }
      });
      
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF('p', 'mm', 'a4');
      
      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      let heightLeft = imgHeight;
      let position = 0;

      // Add first page
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Add subsequent pages if needed
      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`research_report_${Date.now()}.pdf`);
    } catch (err: any) {
      console.error('PDF generation failed:', err);
      setError(`PDF generation failed: ${err.message || 'Unknown error'}. Try using "Copy Markdown" instead.`);
    } finally {
      setIsGeneratingPDF(false);
    }
  };

  const handleResearch = async (searchQuery: string) => {
    if (!searchQuery.trim()) return;
    setQuery(searchQuery);
    setIsSearching(true);
    setReport(null);
    setError(null);
    setSteps([]);

    try {
      const result = await runResearch(searchQuery, (updatedSteps) => {
        setSteps(updatedSteps);
      });
      setReport(result.finalReport);
    } catch (err: any) {
      setError(err.message || "An unexpected error occurred during research.");
    } finally {
      setIsSearching(false);
    }
  };

  const downloadColab = () => {
    if (!report) return;
    const code = generateColabCode(query, report);
    const blob = new Blob([code], { type: 'application/x-ipynb+json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `research_report_${Date.now()}.ipynb`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-gray-100 font-sans selection:bg-blue-500/30">
      {/* Header */}
      <header className="border-b border-white/10 bg-black/50 backdrop-blur-md sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <BrainCircuit className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-xl tracking-tight">Deep Researcher <span className="text-blue-500">AI</span></span>
          </div>
          <div className="flex items-center gap-4">
            <button className="text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1">
              <Github className="w-4 h-4" />
              Source
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-12">
        {!isSearching && !report && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center space-y-8 mb-16"
          >
            <div className="space-y-4">
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight bg-gradient-to-b from-white to-gray-500 bg-clip-text text-transparent">
                Multi-Agent Deep Research
              </h1>
              <p className="text-xl text-gray-400 max-w-2xl mx-auto">
                Deploy a specialized swarm of AI agents to investigate complex topics, 
                synthesize data, and build comprehensive reports in seconds.
              </p>
            </div>

            <div className="relative max-w-2xl mx-auto">
              <div className="absolute inset-y-0 left-4 flex items-center pointer-events-none">
                <Search className="w-5 h-5 text-gray-500" />
              </div>
              <input 
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && handleResearch(query)}
                placeholder="What would you like to investigate today?"
                className="w-full bg-white/5 border border-white/10 rounded-2xl py-4 pl-12 pr-32 focus:outline-none focus:ring-2 focus:ring-blue-500/50 transition-all text-lg"
              />
              <button 
                onClick={() => handleResearch(query)}
                className="absolute right-2 top-2 bottom-2 px-6 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-medium transition-colors flex items-center gap-2"
              >
                Research
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="pt-8">
              <p className="text-sm text-gray-500 mb-4 uppercase tracking-widest font-semibold">Suggested Investigations</p>
              <div className="flex flex-wrap justify-center gap-3">
                {SUGGESTED_TOPICS.map((topic) => (
                  <button
                    key={topic}
                    onClick={() => handleResearch(topic)}
                    className="px-4 py-2 rounded-full bg-white/5 border border-white/10 hover:border-blue-500/50 hover:bg-blue-500/5 transition-all text-sm text-gray-400 hover:text-blue-400"
                  >
                    {topic}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}

        {/* Research Progress View */}
        {(isSearching || steps.length > 0) && !report && (
          <div className="space-y-8">
            <div className="bg-white/5 border border-white/10 rounded-3xl p-8 backdrop-blur-sm">
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-2xl font-bold mb-1">Researching: {query}</h2>
                  <p className="text-gray-400 text-sm">Agents are collaborating on your request...</p>
                </div>
                {isSearching && <Loader2 className="w-6 h-6 text-blue-500 animate-spin" />}
              </div>

              <div className="space-y-6">
                {steps.map((step, idx) => (
                  <motion.div 
                    key={step.agent}
                    initial={{ opacity: 0, x: -10 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className={cn(
                      "flex items-start gap-4 p-4 rounded-2xl transition-all border",
                      step.status === 'running' ? "bg-blue-500/5 border-blue-500/20" : "bg-transparent border-transparent"
                    )}
                  >
                    <div className={cn(
                      "w-10 h-10 rounded-xl flex items-center justify-center shrink-0",
                      step.status === 'completed' ? "bg-green-500/20 text-green-500" : 
                      step.status === 'running' ? "bg-blue-500/20 text-blue-500" :
                      step.status === 'error' ? "bg-red-500/20 text-red-500" : "bg-white/5 text-gray-600"
                    )}>
                      {step.status === 'completed' ? <CheckCircle2 className="w-5 h-5" /> :
                       step.status === 'running' ? <Loader2 className="w-5 h-5 animate-spin" /> :
                       step.status === 'error' ? <AlertCircle className="w-5 h-5" /> :
                       <div className="w-2 h-2 rounded-full bg-current" />}
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between">
                        <h3 className="font-bold text-lg">{step.agent} Agent</h3>
                        <span className={cn(
                          "text-xs font-mono uppercase tracking-wider px-2 py-1 rounded",
                          step.status === 'completed' ? "text-green-500" : 
                          step.status === 'running' ? "text-blue-500" : "text-gray-600"
                        )}>
                          {step.status}
                        </span>
                      </div>
                      <p className="text-gray-400 mt-1">{step.message}</p>
                      {step.output && (
                        <motion.div 
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          className="mt-4 p-4 bg-black/40 rounded-xl border border-white/5 text-xs font-mono text-gray-500 overflow-hidden"
                        >
                          <div className="max-h-32 overflow-y-auto scrollbar-hide">
                            {step.output}
                          </div>
                        </motion.div>
                      )}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Final Report View */}
        {report && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-8"
          >
            <div className="flex items-center justify-between">
              <button 
                onClick={() => { setReport(null); setSteps([]); setQuery(''); }}
                className="text-sm text-gray-400 hover:text-white flex items-center gap-2 transition-colors"
              >
                <ArrowRight className="w-4 h-4 rotate-180" />
                New Research
              </button>
              <div className="flex gap-3">
                <button 
                  onClick={copyToClipboard}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm font-medium flex items-center gap-2 transition-all"
                >
                  {copied ? <ClipboardCheck className="w-4 h-4 text-green-500" /> : <Clipboard className="w-4 h-4" />}
                  {copied ? 'Copied!' : 'Copy Markdown'}
                </button>
                <button 
                  onClick={downloadColab}
                  className="px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/10 rounded-xl text-sm font-medium flex items-center gap-2 transition-all"
                >
                  <Download className="w-4 h-4" />
                  Download Colab
                </button>
                <button 
                  onClick={exportToPDF}
                  disabled={isGeneratingPDF}
                  className="px-4 py-2 bg-blue-600 hover:bg-blue-500 disabled:bg-blue-800 disabled:cursor-not-allowed text-white rounded-xl text-sm font-medium flex items-center gap-2 transition-all"
                >
                  {isGeneratingPDF ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <FileText className="w-4 h-4" />
                  )}
                  {isGeneratingPDF ? 'Generating...' : 'Export PDF'}
                </button>
              </div>
            </div>

            <div 
              ref={reportRef}
              id="report-container"
              className="bg-[#0a0a0a] border border-white/10 rounded-3xl p-8 md:p-12 backdrop-blur-sm shadow-2xl"
            >
              <div className="prose prose-invert prose-blue max-w-none">
                <Markdown components={{
                  h1: ({node, ...props}) => <h1 className="text-4xl font-bold mb-8 border-b border-white/10 pb-4" {...props} />,
                  h2: ({node, ...props}) => <h2 className="text-2xl font-bold mt-12 mb-6 text-blue-400" {...props} />,
                  h3: ({node, ...props}) => <h3 className="text-xl font-bold mt-8 mb-4" {...props} />,
                  p: ({node, ...props}) => <p className="text-gray-300 leading-relaxed mb-4" {...props} />,
                  ul: ({node, ...props}) => <ul className="list-disc list-inside space-y-2 mb-6 text-gray-300" {...props} />,
                  li: ({node, ...props}) => <li className="marker:text-blue-500" {...props} />,
                  blockquote: ({node, ...props}) => <blockquote className="border-l-4 border-blue-500 bg-blue-500/5 p-4 rounded-r-xl italic my-6" {...props} />,
                }}>
                  {report}
                </Markdown>
              </div>
            </div>
          </motion.div>
        )}

        {error && (
          <div className="mt-8 p-6 bg-red-500/10 border border-red-500/20 rounded-2xl flex items-start gap-4">
            <AlertCircle className="w-6 h-6 text-red-500 shrink-0" />
            <div>
              <h3 className="font-bold text-red-500">Research Error</h3>
              <p className="text-red-400/80 text-sm mt-1">{error}</p>
              <button 
                onClick={() => handleResearch(query)}
                className="mt-4 px-4 py-2 bg-red-500 text-white rounded-lg text-sm font-medium hover:bg-red-600 transition-colors"
              >
                Retry Research
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Features Grid */}
      {!isSearching && !report && (
        <section className="max-w-7xl mx-auto px-4 py-24 border-t border-white/5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-blue-500/30 transition-all group">
              <div className="w-12 h-12 bg-blue-500/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Database className="w-6 h-6 text-blue-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Contextual Retrieval</h3>
              <p className="text-gray-400">Our Retriever Agent pulls real-time data from academic papers, news, and live APIs using Google Search grounding.</p>
            </div>
            <div className="p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-purple-500/30 transition-all group">
              <div className="w-12 h-12 bg-purple-500/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <ShieldCheck className="w-6 h-6 text-purple-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Critical Analysis</h3>
              <p className="text-gray-400">Every piece of data is cross-referenced. The Analyst Agent highlights contradictions and validates source credibility.</p>
            </div>
            <div className="p-8 rounded-3xl bg-white/5 border border-white/10 hover:border-orange-500/30 transition-all group">
              <div className="w-12 h-12 bg-orange-500/20 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
                <Zap className="w-6 h-6 text-orange-500" />
              </div>
              <h3 className="text-xl font-bold mb-3">Insight Synthesis</h3>
              <p className="text-gray-400">Beyond just facts, our Synthesizer Agent uses advanced reasoning chains to suggest hypotheses and emerging trends.</p>
            </div>
          </div>
        </section>
      )}

      <footer className="max-w-7xl mx-auto px-4 py-12 border-t border-white/5 text-center">
        <p className="text-gray-500 text-sm">
          Powered by Gemini 3.1 Flash & Multi-Agent Orchestration. 
          Built for deep investigations.
        </p>
      </footer>
    </div>
  );
}
