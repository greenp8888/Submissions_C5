# Deep Researcher AI: Multi-Agent Workflow

This document explains the internal orchestration and data flow of the Deep Researcher AI application.

## System Overview

The application uses a **Sequential Multi-Agent Swarm** architecture. Each agent is a specialized instance of the Gemini 3.1 Flash model, configured with specific system instructions and tools to perform a single part of the research lifecycle.

---

## Step-by-Step Workflow

### 1. User Input & Initialization
- **Input:** The user provides a research query (e.g., "The future of solid-state batteries").
- **Action:** The UI initializes the `ResearchStep` array and triggers the `runResearch` orchestrator.

### 2. Planner Agent (The Architect)
- **Role:** Analyzes the high-level query and breaks it down into actionable search strategies.
- **Output:** A JSON array of 3-5 specific, optimized search queries designed to cover different angles of the topic (e.g., technical, economic, and ethical).

### 3. Retriever Agent (The Librarian)
- **Role:** Executes the search queries using **Google Search Grounding**.
- **Action:** It fetches real-time data from the web, filtering for high-quality sources like academic papers, news, and official reports.
- **Output:** A massive context block containing raw, retrieved information.

### 4. Analyst Agent (The Critic)
- **Role:** Performs critical evaluation of the retrieved data.
- **Action:** It looks for contradictions between sources, validates the credibility of the information, and extracts core facts.
- **Output:** A synthesized analysis highlighting verified facts and potential biases.

### 5. Synthesizer Agent (The Strategist)
- **Role:** Connects disparate facts to find "hidden" patterns.
- **Action:** Uses advanced reasoning to suggest emerging trends, future outlooks, or novel hypotheses based on the analysis.
- **Output:** A list of strategic insights.

### 6. Writer Agent (The Editor)
- **Role:** Compiles all previous outputs into a professional document.
- **Action:** Formats the Query, Analysis, and Insights into a structured Markdown report with standard professional sections.
- **Output:** The final Markdown report displayed in the UI.

---

## Mermaid Flowchart

```mermaid
graph TD
    A[User Query] --> B[Planner Agent]
    B -->|Search Strategies| C[Retriever Agent]
    C -->|Google Search Grounding| D[Raw Data Context]
    D --> E[Analyst Agent]
    E -->|Verified Facts & Contradictions| F[Synthesizer Agent]
    F -->|Hypotheses & Trends| G[Writer Agent]
    G -->|Structured Markdown| H[Final Research Report]
    
    subgraph "Agent Swarm Orchestration"
    B
    C
    E
    F
    G
    end
    
    H --> I[Export PDF]
    H --> J[Download Colab]
    H --> K[Copy Markdown]
```

## Data Persistence & Export
- **Colab Export:** Converts the final report into a `.ipynb` JSON structure for data science workflows.
- **PDF Export:** Uses `html2canvas` and `jsPDF` to capture the rendered Markdown and split it into A4 pages.
- **Markdown:** Raw text is preserved for easy clipboard sharing.
