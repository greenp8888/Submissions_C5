import { GoogleGenAI, GenerateContentResponse } from "@google/genai";

export interface ResearchStep {
  agent: string;
  status: 'pending' | 'running' | 'completed' | 'error';
  message: string;
  output?: string;
}

export interface ResearchResult {
  query: string;
  steps: ResearchStep[];
  finalReport: string;
}

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

const MODEL_NAME = "gemini-3-flash-preview";

export async function runResearch(
  query: string, 
  onStepUpdate: (steps: ResearchStep[]) => void
): Promise<ResearchResult> {
  const steps: ResearchStep[] = [
    { agent: "Planner", status: 'pending', message: "Analyzing research query..." },
    { agent: "Retriever", status: 'pending', message: "Searching for sources..." },
    { agent: "Analyst", status: 'pending', message: "Critically analyzing data..." },
    { agent: "Synthesizer", status: 'pending', message: "Generating insights..." },
    { agent: "Writer", status: 'pending', message: "Compiling final report..." },
  ];

  const updateStep = (index: number, updates: Partial<ResearchStep>) => {
    steps[index] = { ...steps[index], ...updates };
    onStepUpdate([...steps]);
  };

  try {
    // 1. Planner Agent
    updateStep(0, { status: 'running', message: "Breaking down query into search strategies..." });
    const plannerResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `You are a Research Planner. Break down this query into 3-5 specific search queries to get a comprehensive view: "${query}"`,
      config: { responseMimeType: "application/json" }
    });
    const searchQueries = plannerResponse.text;
    updateStep(0, { status: 'completed', message: "Research plan finalized.", output: searchQueries });

    // 2. Retriever Agent
    updateStep(1, { status: 'running', message: "Searching Google for high-quality sources..." });
    const retrieverResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Search for the following and provide a detailed summary of findings: ${searchQueries}`,
      config: {
        tools: [{ googleSearch: {} }]
      }
    });
    const rawData = retrieverResponse.text;
    updateStep(1, { status: 'completed', message: "Retrieved data from multiple sources.", output: rawData });

    // 3. Analyst Agent
    updateStep(2, { status: 'running', message: "Validating sources and checking for contradictions..." });
    const analystResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Critically analyze the following research data. Highlight contradictions, validate source credibility, and summarize key facts: \n\n ${rawData}`,
    });
    const analysis = analystResponse.text;
    updateStep(2, { status: 'completed', message: "Analysis complete. Key facts extracted.", output: analysis });

    // 4. Synthesizer Agent
    updateStep(3, { status: 'running', message: "Connecting the dots and forming hypotheses..." });
    const synthesizerResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Based on this analysis, suggest 3-5 emerging trends or hypotheses for further investigation: \n\n ${analysis}`,
    });
    const insights = synthesizerResponse.text;
    updateStep(3, { status: 'completed', message: "Insights generated.", output: insights });

    // 5. Writer Agent
    updateStep(4, { status: 'running', message: "Writing the final structured report..." });
    const currentDate = new Date().toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    const writerResponse = await ai.models.generateContent({
      model: MODEL_NAME,
      contents: `Write a professional, structured research report in Markdown based on the following:
      Current Date: ${currentDate}
      Query: ${query}
      Analysis: ${analysis}
      Insights: ${insights}
      
      Include the current date in the report header.
      Include sections for Executive Summary, Methodology, Key Findings, Critical Analysis, and Future Outlook.`,
    });
    const finalReport = writerResponse.text || "Failed to generate report.";
    updateStep(4, { status: 'completed', message: "Report finalized.", output: finalReport });

    return { query, steps, finalReport };
  } catch (error) {
    console.error("Research failed:", error);
    const errorMsg = error instanceof Error ? error.message : String(error);
    steps.forEach(s => { if (s.status === 'running') updateStep(steps.indexOf(s), { status: 'error', message: errorMsg }); });
    throw error;
  }
}

export function generateColabCode(query: string, report: string) {
  const currentDate = new Date().toLocaleDateString('en-US', { 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });
  const notebook = {
    cells: [
      {
        cell_type: "markdown",
        metadata: {},
        source: [
          "# Deep Researcher AI Report\n",
          `## Query: ${query}\n`,
          `**Date:** ${currentDate}\n\n`,
          "Generated via Deep Researcher AI App"
        ]
      },
      {
        cell_type: "markdown",
        metadata: {},
        source: [report]
      }
    ],
    metadata: {
      kernelspec: {
        display_name: "Python 3",
        language: "python",
        name: "python3"
      },
      language_info: {
        codemirror_mode: {
          name: "ipython",
          version: 3
        },
        file_extension: ".py",
        mimetype: "text/x-python",
        name: "python",
        nbconvert_exporter: "python",
        pygments_lexer: "ipython",
        version: "3.8.10"
      }
    },
    nbformat: 4,
    nbformat_minor: 0
  };

  return JSON.stringify(notebook, null, 2);
}
