import React from 'react';
import { motion } from 'motion/react';
import { 
  Search, 
  BrainCircuit, 
  Database, 
  ShieldCheck, 
  Zap, 
  FileText, 
  ArrowRight,
  User,
  Globe
} from 'lucide-react';

const Node = ({ icon: Icon, title, description, color, delay }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay }}
    className="flex flex-col items-center text-center space-y-3 p-6 rounded-2xl bg-white/5 border border-white/10 w-64 relative z-10"
  >
    <div className={`w-12 h-12 rounded-xl flex items-center justify-center bg-${color}-500/20 text-${color}-500`}>
      <Icon className="w-6 h-6" />
    </div>
    <div>
      <h3 className="font-bold text-white">{title}</h3>
      <p className="text-xs text-gray-500 mt-1 leading-relaxed">{description}</p>
    </div>
  </motion.div>
);

const Connector = ({ delay }: { delay: number }) => (
  <div className="flex flex-col items-center py-4 relative h-12">
    <motion.div 
      initial={{ height: 0 }}
      animate={{ height: '100%' }}
      transition={{ delay, duration: 0.5 }}
      className="w-px bg-gradient-to-b from-blue-500/50 to-purple-500/50"
    />
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ delay: delay + 0.4 }}
      className="absolute bottom-0"
    >
      <ArrowRight className="w-4 h-4 text-purple-500 rotate-90" />
    </motion.div>
  </div>
);

export default function Flowchart() {
  return (
    <div className="flex flex-col items-center py-12 px-4 bg-[#0a0a0a] rounded-3xl border border-white/5 overflow-hidden">
      <div className="mb-12 text-center">
        <h2 className="text-3xl font-bold text-white mb-2">System Architecture</h2>
        <p className="text-gray-500">Sequential Multi-Agent Research Orchestration</p>
      </div>

      <div className="flex flex-col items-center">
        {/* User Input */}
        <Node 
          icon={User} 
          title="User Query" 
          description="Natural language research request" 
          color="blue" 
          delay={0.1}
        />
        <Connector delay={0.3} />

        {/* Planner */}
        <Node 
          icon={BrainCircuit} 
          title="Planner Agent" 
          description="Deconstructs query into search strategies" 
          color="indigo" 
          delay={0.5}
        />
        <Connector delay={0.7} />

        {/* Retriever */}
        <div className="relative">
          <Node 
            icon={Database} 
            title="Retriever Agent" 
            description="Fetches real-time data from web sources" 
            color="cyan" 
            delay={0.9}
          />
          {/* Side Tool */}
          <motion.div 
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 1.1 }}
            className="absolute left-full ml-8 top-1/2 -translate-y-1/2 flex items-center gap-3 bg-blue-500/10 border border-blue-500/20 p-3 rounded-xl whitespace-nowrap"
          >
            <Globe className="w-4 h-4 text-blue-400" />
            <span className="text-xs font-mono text-blue-400">Google Search Grounding</span>
          </motion.div>
        </div>
        <Connector delay={1.3} />

        {/* Analyst */}
        <Node 
          icon={ShieldCheck} 
          title="Analyst Agent" 
          description="Validates sources & identifies contradictions" 
          color="emerald" 
          delay={1.5}
        />
        <Connector delay={1.7} />

        {/* Synthesizer */}
        <Node 
          icon={Zap} 
          title="Synthesizer Agent" 
          description="Generates hypotheses & emerging trends" 
          color="amber" 
          delay={1.9}
        />
        <Connector delay={2.1} />

        {/* Writer */}
        <Node 
          icon={FileText} 
          title="Writer Agent" 
          description="Compiles final structured Markdown report" 
          color="rose" 
          delay={2.3}
        />
      </div>

      <div className="mt-16 grid grid-cols-3 gap-4 w-full max-w-2xl">
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold block mb-1">Export</span>
          <span className="text-sm text-gray-300">PDF Document</span>
        </div>
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold block mb-1">Export</span>
          <span className="text-sm text-gray-300">Colab Notebook</span>
        </div>
        <div className="p-4 rounded-xl bg-white/5 border border-white/10 text-center">
          <span className="text-[10px] uppercase tracking-widest text-gray-500 font-bold block mb-1">Export</span>
          <span className="text-sm text-gray-300">Markdown Text</span>
        </div>
      </div>
    </div>
  );
}
